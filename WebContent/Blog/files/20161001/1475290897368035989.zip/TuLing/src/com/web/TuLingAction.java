package com.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.util.PostServer;
import com.util.ResponseUtil;


public class TuLingAction extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String info=request.getParameter("info");
		System.out.println(info);
		String key="8edce3ce905a4c1dbb965e6b35c3834d";
		JSONObject jsonObject=new JSONObject();
		jsonObject.put("key", key);
		jsonObject.put("info",info);
		String result = PostServer.SendPost(jsonObject.toString(), "http://www.tuling123.com/openapi/api");
		System.out.println(result);
		try {
			ResponseUtil.write(result, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
