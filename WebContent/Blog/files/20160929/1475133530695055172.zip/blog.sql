/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.1.49-community : Database - db_blog
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_blog` /*!40100 DEFAULT CHARACTER SET utf8 */;

/*Table structure for table `t_blog` */

CREATE TABLE `t_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `author` varchar(20) DEFAULT NULL,
  `readNum` int(11) DEFAULT NULL,
  `publishTime` datetime DEFAULT NULL,
  `blogTypeId` int(11) DEFAULT NULL,
  `blogTagId` int(11) DEFAULT NULL,
  `isRecommend` int(5) DEFAULT NULL,
  `recommendOrder` int(11) DEFAULT NULL,
  `coverImageName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogTypeId` (`blogTypeId`),
  KEY `blogTagId` (`blogTagId`),
  CONSTRAINT `t_blog_ibfk_1` FOREIGN KEY (`blogTypeId`) REFERENCES `t_blogtype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_blog` */

LOCK TABLES `t_blog` WRITE;

UNLOCK TABLES;

/*Table structure for table `t_blogadvice` */

CREATE TABLE `t_blogadvice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickName` varchar(20) DEFAULT NULL,
  `userIP` varchar(20) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `publishTime` datetime DEFAULT NULL,
  `reply` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_blogadvice` */

LOCK TABLES `t_blogadvice` WRITE;

UNLOCK TABLES;

/*Table structure for table `t_bloger` */

CREATE TABLE `t_bloger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `nickName` varchar(20) DEFAULT NULL,
  `job` varchar(20) DEFAULT NULL,
  `hobby` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `webClick` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `t_bloger` */

LOCK TABLES `t_bloger` WRITE;

insert  into `t_bloger`(`id`,`userName`,`password`,`nickName`,`job`,`hobby`,`email`,`webClick`) values (1,'ldb','123456','D.B | 氧化钡','学生、未来的程序猿','瞎折腾一些东西','571002217@qq.com',0);

UNLOCK TABLES;

/*Table structure for table `t_blogtag` */

CREATE TABLE `t_blogtag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tagName` varchar(20) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `typeId` (`typeId`),
  CONSTRAINT `t_blogtag_ibfk_1` FOREIGN KEY (`typeId`) REFERENCES `t_blogtype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_blogtag` */

LOCK TABLES `t_blogtag` WRITE;

UNLOCK TABLES;

/*Table structure for table `t_blogtype` */

CREATE TABLE `t_blogtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `t_blogtype` */

LOCK TABLES `t_blogtype` WRITE;

insert  into `t_blogtype`(`id`,`typeName`) values (1,'技术探讨'),(2,'技术干货'),(3,'项目分享'),(4,'经验总结'),(5,'碎言碎语');

UNLOCK TABLES;

/*Table structure for table `t_comment` */

CREATE TABLE `t_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickName` varchar(20) DEFAULT NULL,
  `userIP` varchar(20) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `commentTime` datetime DEFAULT NULL,
  `reply` varchar(1000) DEFAULT NULL,
  `blogId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogId` (`blogId`),
  CONSTRAINT `t_comment_ibfk_1` FOREIGN KEY (`blogId`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_comment` */

LOCK TABLES `t_comment` WRITE;

UNLOCK TABLES;

/*Table structure for table `t_link` */

CREATE TABLE `t_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `linkName` varchar(20) DEFAULT NULL,
  `linkUrl` varchar(100) DEFAULT NULL,
  `linkEmail` varchar(50) DEFAULT NULL,
  `orderNum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_link` */

LOCK TABLES `t_link` WRITE;

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
